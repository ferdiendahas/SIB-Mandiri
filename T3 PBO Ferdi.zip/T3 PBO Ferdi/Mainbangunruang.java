public class Mainbangunruang {
    public static void main(String[] var0) {

        Cube kubus = new Cube(5);
        System.out.println("sisi kubus = " + kubus.getCube());
        System.out.println("volume kubus = " + kubus.getvol());
        System.out.println("============================");

        Beam balok = new Beam(4,3,5);
        System.out.println("panjang balok = " + balok.getpanjang());
        System.out.println("lebar balok = " + balok.getlebar());
        System.out.println("tinggi balok = " + balok.gettinggi());
        System.out.println("volume balok = " + balok.getvol());
        System.out.println("============================");

        Tube tabung = new Tube(2,6);
        System.out.println("jari-jari tabung adalah = " + tabung.getjari());
        System.out.println("tinggi tabung adalah = " + tabung.gettinggi());
        System.out.println("volume tabung adalah = " + tabung.getvol());
        System.out.println("============================");

        RectangularPyramid limas = new RectangularPyramid(4,6);
        System.out.println("alas limas segi empat = " + limas.getalas());
        System.out.println("tinggi limas segi empat = " + limas.gettinggi());
        System.out.println("volume limas segi empat = " + limas.getvol());
        System.out.println("============================");

        Ball bola = new Ball(3);
        System.out.println("jari-jari bola = " + bola.getjari());
        System.out.println("volume bola = " + bola.getvol());
        System.out.println("============================");

        Object[] br = new Object[5];
           br[0] = new Hemisphere(6);
           br[1] = new Cone(6,5);
           br[2] = new TriangularPyramid(4,5,8);
           br[3] = new TriangularPrism(3, 5, 6);
           br[4] = new RectangularPrism(3, 5, 6, 8);

           double totalVolume = 0;
           int count = 0;
   
           for (Object obj : br) {
               if (obj instanceof Hemisphere) {
                   totalVolume += ((Hemisphere) obj).getvol();
               } else if (obj instanceof Cone) {
                   totalVolume += ((Cone) obj).getvol();
               } else if (obj instanceof TriangularPyramid) {
                   totalVolume += ((TriangularPyramid) obj).getvol();
               } else if (obj instanceof TriangularPrism) {
                   totalVolume += ((TriangularPrism) obj).getvol();
               } else if (obj instanceof RectangularPrism) {
                   totalVolume += ((RectangularPrism) obj).getvol();
               }
               count++;
           }
   
           double rataRataVolume = totalVolume / count;
           System.out.println("Rata-rata volume dari bangun ruang: " + rataRataVolume);
        
    }
}
