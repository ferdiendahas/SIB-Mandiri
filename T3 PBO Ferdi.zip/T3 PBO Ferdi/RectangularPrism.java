public class RectangularPrism {
    int panjang;
    int lebar;
    int tinggiSegiempat;
    int tinggiPrisma;
    public RectangularPrism(int p, int l, int tS, int tP){
        this.panjang = p;
        this.lebar = l;
        this.tinggiSegiempat = tS;
        this.tinggiPrisma = tP;
    }

    public int getPanjang(){
        return panjang;
    }

    public int getLebar(){
        return lebar;
    }

    public int getTinggiSegiempat(){
        return tinggiSegiempat;
    }

    public int getTinggiPrisma(){
        return tinggiPrisma;
    }
    
    public int getvol(){
        return (panjang * lebar * tinggiSegiempat) * tinggiPrisma;
    }
    
}
