public class Cone {
    int jari;
    int tinggi;

    public Cone(int j, int t){
        this.jari = j;
        this.tinggi = t;
    }

    public int getJari(){
        return jari;
    }

    public int getTinggi(){
        return tinggi;
    }

    public double getvol(){
        return (Math.PI * jari * jari * tinggi)/3;
    }
}
