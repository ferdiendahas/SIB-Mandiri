public class TriangularPyramid {
    int alas;
    int tinggiSegitiga;
    int tinggiLimas;
    public TriangularPyramid(int a, int tS, int tL){
        this.alas = a;
        this.tinggiSegitiga = tS;
        this.tinggiLimas = tL;
    }

    public int getAlas(){
        return alas;
    }

    public int getTinggiSegitiga(){
        return tinggiSegitiga;
    }

    public int getTinggiLimas(){
        return tinggiLimas;
    }

    public int getvol(){
        return (((alas * tinggiSegitiga)/2) * tinggiLimas)/3;
    }
}
