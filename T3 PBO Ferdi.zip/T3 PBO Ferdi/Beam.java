 public class Beam {
    int panjang;
    int lebar;
    int tinggi;
    public  Beam(int p, int l, int t){
       this.panjang = p;
       this.lebar = l;
       this.tinggi = t;
    }

    public int getlebar(){
        return lebar;
    }
    public int getpanjang(){
        return panjang; 
    }
    public int gettinggi(){
        return tinggi;
    }

    public int getvol(){
        return (panjang * lebar * tinggi);
    }

    
}
 
    

