public class RectangularPyramid {
        int alas;
        int tinggi;
        public RectangularPyramid(int a, int t){
            this.alas = a;
            this.tinggi = t;
        }
    
        public int getalas(){
            return alas;
        }
    
        public int gettinggi(){
            return tinggi;
        }
        
        public int getvol(){
            return   (alas * alas * tinggi)/3;
        }
    
    
}
