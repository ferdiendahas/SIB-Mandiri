public class TriangularPrism {
    int alas;
    int tinggiSegitiga;
    int tinggiPrisma;
    public TriangularPrism(int a, int tS, int tP){
        this.alas = a;
        this.tinggiSegitiga = tS;
        this.tinggiPrisma = tP;
    }

    public int getAlas(){
        return alas;
    }

    public int getTinggiSegitiga(){
        return tinggiSegitiga;
    }

    public int getTinggiPrisma(){
        return tinggiPrisma;
    }

    public int getvol(){
        return ((alas * tinggiSegitiga)/2) * tinggiPrisma;
    }
}
