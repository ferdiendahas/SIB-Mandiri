public class Cube {
        int sisi;
        public Cube(int s){
            this.sisi = s;
        }
        
        public int getCube(){
            return sisi;
        }

        public int getvol(){
            return sisi * sisi * sisi;
        }
    
    }
     
        
    
    

