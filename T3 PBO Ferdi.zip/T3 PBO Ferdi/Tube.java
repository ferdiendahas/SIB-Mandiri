public class Tube {
        int jari;
        int tinggi;
        public Tube(int j, int t){
            this.jari = j;
            this.tinggi = t;
        }
    
        public int getjari(){
            return jari;
        }

        public int gettinggi(){
            return tinggi;
        }
        
        public double getvol(){
            return Math.PI * jari * jari * tinggi;
        }
        


}
