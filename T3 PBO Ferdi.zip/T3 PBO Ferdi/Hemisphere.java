public class Hemisphere {
    int jari;
    public Hemisphere(int j){
       this.jari = j;
    }

    public int getjari(){
        return jari;
    }
    
    public double getvol(){
        return (2 * Math.PI * jari * jari * jari)/3;
    }

}
