public class Ball {
        int jari;
        public Ball(int j){
           this.jari = j;
        }
    
        public int getjari(){
            return jari;
        }
        
        public double getvol(){
            return (4 * Math.PI * jari * jari * jari)/3;
        }

}
