// public class Mainbangunruang {
//     public static void main(String[] var0) {

//         Cube kubus = new Cube();
//         kubus.setsisi(5);
//         System.out.println("sisi kubus = " + kubus.getsisi());
//         System.out.println("volume kubus = " + kubus.getvol());
//         System.out.println("luas permukaan kubus = " + kubus.getluaspermukaan());
//         System.out.println("keliling kubus = " + kubus.getkel());
//         System.out.println("luas sisi kubus = " + kubus.getluassisi());
//         System.out.println("============================");

//         Beam balok = new Beam();
//         balok.setpanjang(2);
//         balok.setlebar(4);
//         balok.settinggi(5);
//         System.out.println("panjang balok = " + balok.getpanjang());
//         System.out.println("lebar balok = " + balok.getlebar());
//         System.out.println("tinggi balok = " + balok.gettinggi());
//         System.out.println("volume balok = " + balok.getvol());
//         System.out.println("luas permukaan balok = " + balok.getluas());
//         System.out.println("keliling balok = " + balok.getkel());
//         System.out.println("============================");

//         Tube tabung = new Tube();
//         tabung.setjari(2);
//         tabung.settinggi(6);
//         System.out.println("jari-jari tabung adalah = " + tabung.getjari());
//         System.out.println("tinggi tabung adalah = " + tabung.gettinggi());
//         System.out.println("volume tabung adalah = " + tabung.getvol());
//         System.out.println("luas permukaan tabung tanpa tutup adalah = " + tabung.getluaspermukaan());
//         System.out.println("luas permukaan tabung tanpa  adalah = " + tabung.getLuasPermukaanTanpaTutup());
//         System.out.println("luas selimut tabung adalah = " + tabung.getluasselimut());
//         System.out.println("============================");

//         RectangularPyramid limas = new RectangularPyramid();
//         limas.setalas(4);
//         limas.settinggi(6);
//         System.out.println("alas limas segi empat = " + limas.getalas());
//         System.out.println("tinggi limas segi empat = " + limas.gettinggi());
//         System.out.println("volume limas segi empat = " + limas.getvol());
//         System.out.println("luas permukaan limas segi empat = " + limas.getluaspermukaan());
//         System.out.println("============================");

//         Ball bola = new Ball();
//         bola.setjari(3);
//         System.out.println("jari-jari bola = " + bola.getjari());
//         System.out.println("volume bola = " + bola.getvol());
//         System.out.println("luas permukaan bola = " + bola.getluaspermukaan());
//         System.out.println("luas permukaan setengah bola = " + bola.getLuasPermukaanSetengahBola());
//     }
// }
