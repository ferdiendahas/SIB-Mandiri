public class RectangularPyramid {
        int alas;
        int tinggi;
        public void setalas(int input_alas){
            alas = input_alas;
        }
    
        public int getalas(){
            return alas;
        }
    
        public void settinggi(int input_tinggi){
            tinggi = input_tinggi;
        }
    
        public int gettinggi(){
            return tinggi;
        }
        
        public int getvol(){
            return   (alas * alas * tinggi)/3;
        }

        public int getluaspermukaan(){
            return (alas * alas) + (4 * ((alas * tinggi)/2));
        }
    
        
    
     
        
    
    
}
