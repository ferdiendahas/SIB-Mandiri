public class Circle {
    double jari;
    double phi;

    public void setjari(double input_jari){
        jari = input_jari;
    }

    public double getjari(){
        return jari;
    }

    public void setphi(double input_phi){
        phi = input_phi;
    }

    public double getphi(){
        return phi;
    }

    public double getdiameter(){
        return 2 * jari;
    }
    public double getluas(){
        return phi * (jari * jari);
    }

    public double getkel(){
        return 2 * phi * jari;
    }

}
