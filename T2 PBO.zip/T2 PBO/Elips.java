public class Elips {
    double mayor;
    double minor;
    double phi;

    public void setmayor(double input_mayor){
        mayor = input_mayor;
    }

    public double getmayor(){
        return mayor;
    }

    public void setminor(double input_minor){
        minor = input_minor;
    }

    public double getminor(){
        return minor;
    }

    public void setphi(double input_phi){
        phi = input_phi;
    }

    public double getphi(){
        return phi;
    }
    public double getluas(){
        return phi * mayor * minor;
    }
    public double getkel(){
        return (2 * phi) * (Math.sqrt(((mayor * mayor)+(minor * minor))/2.0));
    }

}
