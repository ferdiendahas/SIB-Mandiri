public class Ball {
        int jari;
        public void setjari(int input_jari){
            jari = input_jari;
        }
    
        public int getjari(){
            return jari;
        }
        
        public double getvol(){
            return (4 * Math.PI * jari * jari * jari)/3;
        }
        
        public double getluaspermukaan(){
        return 4 * Math.PI * jari * jari;
        }

        public double getLuasPermukaanSetengahBola(){
            return 2 * Math.PI * jari ;
        }

}
