 public class Beam {
    int lebar;
    int panjang;
    int tinggi;
    public void setlebar(int input_lebar){
        lebar = input_lebar;
    }

    public int getlebar(){
        return lebar;
    }
    public void setpanjang(int input_panjang){
        panjang = input_panjang;
    }

    public int getpanjang(){
        return panjang; 
    }

    public void settinggi(int input_tinggi){
        tinggi = input_tinggi;
    }

    public int gettinggi(){
        return tinggi;
    }
    public int getluas(){
        return 2 * ((lebar * panjang) + (panjang * tinggi) + (lebar * tinggi));
    }

    public int getvol(){
        return (lebar * panjang * tinggi);
    }

    public int getkel(){
        return 4 * (lebar * panjang * tinggi);
    }
    
}
 
    

