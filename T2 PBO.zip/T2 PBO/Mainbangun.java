
public class Mainbangun {
    public static void main(String[] args){
        Square kotak1 =  new Square();
        kotak1.setsisi(5);
        System.out.println("sisi persegi = " + kotak1.getsisi());
        System.out.println("luas persegi = " + kotak1.getluas());
        System.out.println("keliling persegi = " + kotak1.getkel());
        System.out.println("============================");

        Retangle kotak2 =  new Retangle();
        kotak2.setlebar(5); 
        kotak2.setpanjang(10);
        System.out.println("panjang persegi panjang = " + kotak2.getpanjang());
        System.out.println("lebar persegi panjang = " + kotak2.getlebar());
        System.out.println("luas persegi panjang = " + kotak2.getluas());
        System.out.println("keliling persegi panjang = " + kotak2.getkel());
          
        System.out.println("============================");

        Circle lingkaran1 =  new Circle();
        lingkaran1.setjari(5); 
        lingkaran1.setphi(3.14);
        System.out.println("jari-jari lingkaran = " + lingkaran1.getjari());
        System.out.println("diameter lingkaran = " + lingkaran1.getdiameter());
        System.out.println("luas lingkaran = " + lingkaran1.getluas());
        System.out.println("keliling lingkaran = " + lingkaran1.getkel());

        System.out.println("============================");

        Elips lingkaran2 =  new Elips();
        lingkaran2.setmayor(10); 
        lingkaran2.setminor(5);
        lingkaran2.setphi(3.14);
        System.out.println("jari-jari mayor oval = " + lingkaran2.getmayor());
        System.out.println("jari-jari minor oval = " + lingkaran2.getminor());
        System.out.println("luas oval = " + lingkaran2.getluas());
        System.out.println("keliling oval = " + lingkaran2.getkel());
    }

  
       
    
}
