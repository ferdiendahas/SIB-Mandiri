public class Cube {
        int sisi;
        public void setsisi(int input_sisi){
            sisi = input_sisi;
        }
    
        public int getsisi(){
            return sisi;
        }
    
        
        public int getluaspermukaan(){
            return 6 * (sisi * sisi);
        }
    
        public int getvol(){
            return sisi * sisi * sisi;
        }
    
        public int getkel(){
            return 12 * sisi;
        }
        
        public int getluassisi(){
            return sisi * sisi;
        }
    }
     
        
    
    

