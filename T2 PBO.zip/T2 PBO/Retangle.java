public class Retangle {
    int lebar;
    int panjang;
    public void setlebar(int input_lebar){
        lebar = input_lebar;
    }

    public int getlebar(){
        return lebar;
    }
    public void setpanjang(int input_panjang){
        panjang = input_panjang;
    }

    public int getpanjang(){
        return panjang; 
    }

    public int getluas(){
        return lebar * panjang;
    }

    public int getkel(){
        return 2 * (lebar * panjang) ;
    }
    
}
