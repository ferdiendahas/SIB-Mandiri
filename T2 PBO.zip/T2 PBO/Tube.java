public class Tube {
        int jari;
        int tinggi;
        public void setjari(int input_jari){
            jari = input_jari;
        }
    
        public int getjari(){
            return jari;
        }

        public void settinggi(int input_tinggi){
            tinggi = input_tinggi;
        }

        public int gettinggi(){
            return tinggi;
        }
        
        
        public double getvol(){
            return Math.PI * jari * jari * tinggi;
        }
        
        public double getluaspermukaan(){
        return 2 * Math.PI * jari * (jari + tinggi);
        }

        public double getLuasPermukaanTanpaTutup(){
            return Math.PI * jari * (jari + 2 * tinggi);
        }

        public Double getluasselimut(){
            return 2 * Math.PI * jari * tinggi;
        }
        
        
     
        
    
    


}
