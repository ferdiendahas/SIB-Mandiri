
export default function useBookActions() {
  const handleView = (book) => {
    alert(`Anda melihat buku: ${book.title} seharga ${book.price}`); 
  };

  const handleBuy = (book) => {
    alert(`Anda membeli buku: ${book.title} seharga ${book.price}`);
  };

  return { handleView, handleBuy };
}
