// books.js
const books = [
  {
    id: 1,
    title: "Belajar JavaScript Dasar",
    author: "Andi Prasetyo",
    year: 2021,
    description: "Panduan lengkap untuk pemula yang ingin belajar JavaScript dari nol.",
    image: "https://example.com/images/js-dasar.jpg"
  },
  {
    id: 2,
    title: "React untuk Pemula",
    author: "Dina Sari",
    year: 2022,
    description: "Mengenal konsep dan praktik membuat aplikasi React modern.",
    image: "https://example.com/images/react-pemula.jpg"
  },
  {
    id: 3,
    title: "Mastering Node.js",
    author: "Rudi Hartono",
    year: 2020,
    description: "Buku ini membahas Node.js secara mendalam untuk backend development.",
    image: "https://example.com/images/nodejs.jpg"
  },
  {
    id: 4,
    title: "Belajar TypeScript",
    author: "Sinta Dewi",
    year: 2023,
    description: "Pelajari TypeScript untuk meningkatkan produktivitas di proyek JavaScript.",
    image: "https://example.com/images/typescript.jpg"
  },
  {
    id: 5,
    title: "Next.js untuk Production",
    author: "Bayu Wicaksono",
    year: 2024,
    description: "Panduan membuat aplikasi fullstack dengan Next.js siap deploy.",
    image: "https://example.com/images/nextjs.jpg"
  },
  {
    id: 6,
    title: "Pemrograman Asynchronous",
    author: "Rina Kurnia",
    year: 2021,
    description: "Bahas async, await, promise, dan cara menangani proses asynchronous.",
    image: "https://example.com/images/async.jpg"
  },
  {
    id: 7,
    title: "React Hooks Advanced",
    author: "Taufik Hidayat",
    year: 2023,
    description: "Mendalami penggunaan useState, useEffect, useReducer, dan custom hooks.",
    image: "https://example.com/images/react-hooks.jpg"
  },
  {
    id: 8,
    title: "Membangun REST API",
    author: "Nurul Fadilah",
    year: 2020,
    description: "Step-by-step membuat REST API dengan Express.js dan MongoDB.",
    image: "https://example.com/images/rest-api.jpg"
  },
  {
    id: 9,
    title: "Testing Aplikasi JavaScript",
    author: "Bima Pradana",
    year: 2024,
    description: "Belajar Jest dan React Testing Library untuk membuat aplikasi lebih reliable.",
    image: "https://example.com/images/testing.jpg"
  }
];

export default books;
