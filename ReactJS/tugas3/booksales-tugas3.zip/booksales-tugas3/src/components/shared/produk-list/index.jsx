import { Link } from "react-router-dom";
import books from "../../../Utils/books";
import useBookActions from "../../../Utils/useBookActions";

export default function ProdukList() {
  const { handleView, handleBuy } = useBookActions();

  return (
    <>
      <section className="py-5 text-center container">
        <div className="row py-lg-5">
          <div className="col-lg-6 col-md-8 mx-auto">
            <h1 className="fw-light">Best Seller</h1>
            <p className="lead text-body-secondary">
              Buku dengan penjualan terbaik menurut Bookstore
            </p>
          </div>
        </div>
      </section>

      {/* Album */}
      <div className="album py-5 bg-body-tertiary">
        <div className="container">
          <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
            {books.map((book) => (
              <div className="col" key={book.id}>
                <div className="card shadow-sm">
                  <img
                    src={book.image}
                    className="bd-placeholder-img card-img-top"
                    alt={book.title}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{book.title}</h5>
                    <p className="card-text">{book.description}</p>
                    <div className="d-flex justify-content-between align-items-center">
                      <div className="btn-group">
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-primary"
                          onClick={() => handleView(book)}
                        >
                          View
                        </button>
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-success"
                          onClick={() => handleBuy(book)}
                        >
                          Buy
                        </button>
                      </div>
                      <small className="text-body-secondary">{book.price}</small>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
