export default function Team() {
  return (
    <section className="py-5 bg-light">
      <div className="container">
        <h2 className="text-center fw-bold mb-5">👥 Meet Our Team</h2>
        <div className="row text-center">
          {/* Anggota Team 1 */}
          <div className="col-md-4 mb-4">
            <div className="card border-0 shadow h-100 p-3 team-card">
              <img
                src="https://randomuser.me/api/portraits/men/32.jpg"
                className="rounded-circle mx-auto"
                alt="Team 1"
                width="150"
                height="150"
              />
              <div className="card-body">
                <h5 className="card-title fw-bold">John Doe</h5>
                <p className="card-text text-muted">CEO & Founder</p>
              </div>
            </div>
          </div>

          {/* Anggota Team 2 */}
          <div className="col-md-4 mb-4">
            <div className="card border-0 shadow h-100 p-3 team-card">
              <img
                src="https://randomuser.me/api/portraits/women/44.jpg"
                className="rounded-circle mx-auto"
                alt="Team 2"
                width="150"
                height="150"
              />
              <div className="card-body">
                <h5 className="card-title fw-bold">Jane Smith</h5>
                <p className="card-text text-muted">Marketing Manager</p>
              </div>
            </div>
          </div>

          {/* Anggota Team 3 */}
          <div className="col-md-4 mb-4">
            <div className="card border-0 shadow h-100 p-3 team-card">
              <img
                src="https://randomuser.me/api/portraits/men/76.jpg"
                className="rounded-circle mx-auto"
                alt="Team 3"
                width="150"
                height="150"
              />
              <div className="card-body">
                <h5 className="card-title fw-bold">Michael Lee</h5>
                <p className="card-text text-muted">Lead Developer</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sedikit styling hover effect */}
      <style>{`
        .team-card {
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .team-card:hover {
          transform: scale(1.05);
          box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
      `}</style>
    </section>
  );
}
