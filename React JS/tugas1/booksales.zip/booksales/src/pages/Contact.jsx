export default function Contact() {
  return (
    <div className="container my-5">
      <div className="text-center mb-5">
        <h1 className="fw-bold">📬 Contact Us</h1>
        <p className="lead text-secondary">
          Punya pertanyaan atau saran? Kami senang mendengarnya dari Anda.
        </p>
      </div>

      {/* Info Kontak */}
      <div className="row mb-5 text-center">
        <div className="col-md-4">
          <i className="fa-solid fa-envelope fa-2x mb-2 text-primary"></i>
          <h5>Email</h5>
          <p><a href="mailto:info@bookstore.com">info@bookstore.com</a></p>
        </div>
        <div className="col-md-4">
          <i className="fa-solid fa-phone fa-2x mb-2 text-success"></i>
          <h5>Telepon</h5>
          <p>+62 812 3456 7890</p>
        </div>
        <div className="col-md-4">
          <i className="fa-solid fa-location-dot fa-2x mb-2 text-danger"></i>
          <h5>Alamat</h5>
          <p>Jl. Rungkut No. 12, Surabaya</p>
        </div>
      </div>

      {/* Form Kontak */}
      <div className="card shadow-lg p-4 rounded-4">
        <h4 className="mb-4 text-center">Kirim Pesan</h4>
        <form>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Nama</label>
            <input type="text" className="form-control" id="name" placeholder="Masukkan nama Anda" />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input type="email" className="form-control" id="email" placeholder="nama@email.com" />
          </div>
          <div className="mb-3">
            <label htmlFor="message" className="form-label">Pesan</label>
            <textarea className="form-control" id="message" rows="4" placeholder="Tulis pesan Anda di sini"></textarea>
          </div>
          <div className="text-center">
            <button type="submit" className="btn btn-primary px-4">Kirim</button>
          </div>
        </form>
      </div>

      {/* Sosial Media */}
      <div className="text-center mt-5">
        <p className="mb-3 text-muted">Ikuti kami di sosial media</p>
        <a href="#" className="mx-2"><i className="fa-brands fa-facebook fa-2x text-primary"></i></a>
        <a href="#" className="mx-2"><i className="fa-brands fa-instagram fa-2x text-danger"></i></a>
        <a href="#" className="mx-2"><i className="fa-brands fa-twitter fa-2x text-info"></i></a>
      </div>
    </div>
  );
}
