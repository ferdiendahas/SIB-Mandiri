import Footer from "../../components/shared/footer";
import Header from "../../components/shared/header";
import ProdukList from "../../components/shared/produk-list";

export default function Book(){
    return(
        <>
        <Header/>
        <ProdukList/>
        <Footer/>
        </>
    )
}