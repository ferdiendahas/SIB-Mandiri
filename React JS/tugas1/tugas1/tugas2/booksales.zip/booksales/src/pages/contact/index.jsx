import Contact from "../../components/shared/contact";
import Footer from "../../components/shared/footer";
import Header from "../../components/shared/header";


export default function Book(){
    return(
        <>
        <Header/>
        <Contact/>
        <Footer/>
        </>
    )
}