import Footer from "../components/shared/footer";
import Header from "../components/shared/header";
import Heroes from "../components/shared/heroes";
import ProdukList from "../components/shared/produk-list";

export default function Home(){
    return(
        <>
        {/* Header */}
        <Header/>
        {/* Hero Section */}
        <Heroes/>
        {/* Produk List */}
        <ProdukList/>
        {/* Footer */}
        <Footer/>
        </>
    )
}