import Footer from "../../components/shared/footer";
import Header from "../../components/shared/header";
import ProdukList from "../../components/shared/produk-list";
import Team from "../../components/shared/team";

export default function Book(){
    return(
        <>
        <Header/>
        <Team/>
        <Footer/>
        </>
    )
}