import { NavLink, Link } from "react-router-dom";

export default function Header() {
  return (
    <header className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
      {/* Logo */}
      <div className="col-md-3 mb-2 mb-md-0">
        <Link
          to="/"
          className="d-inline-flex align-items-center text-decoration-none text-black logo"
        >
          <i
            className="fa-solid fa-book fa-2xl me-2"
            style={{ color: "#74C0FC" }}
          ></i>
          <span className="fs-4 fw-bold">Bookstore</span>
        </Link>
      </div>

      {/* Navigation */}
      <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
        {["/", "/book", "/team", "/contact"].map((path, index) => {
          const names = ["Home", "Book", "Team", "Contact"];
          return (
            <li key={index}>
              <NavLink
                to={path}
                className={({ isActive }) =>
                `nav-link px-3 fw-medium ${
                isActive ? "text-primary" : "text-black"
                } nav-hover`
}
              >
                {names[index]}
              </NavLink>
            </li>
          );
        })}
      </ul>

      {/* Buttons */}
      <div className="col-md-3 text-end">
        <Link to="/login">
          <button type="button" className="btn btn-outline-primary me-2">
            Login
          </button>
        </Link>
        <Link to="/register">
          <button type="button" className="btn btn-primary">
            Register
          </button>
        </Link>
      </div>

      {/* CSS tambahan */}
      <style>{`
        .nav-hover {
          transition: color 0.3s, transform 0.2s;
        }
        .nav-hover:hover {
          color: #0d6efd !important;
          transform: scale(1.1);
        }
        .logo:hover i {
          transform: rotate(-15deg);
          transition: transform 0.3s;
        }
      `}</style>
    </header>
  );
}
