import { Link } from "react-router-dom";
export default function ProdukList(){
    return(
        <>
                <section className="py-5 text-center container">
                  <div className="row py-lg-5">
                    <div className="col-lg-6 col-md-8 mx-auto">
                      <h1 className="fw-light">Best Seller</h1>
                      <p className="lead text-body-secondary">
                        Buku dengan penjualan terbaik menurut Bookstore
                      </p>
                      <p>
                        <a href="#" className="btn btn-primary my-2 m-2">View</a>
                        <a href="#" className="btn btn-secondary my-2">Other Book</a>
                      </p>
                    </div>
                  </div>
                </section>

                {/* Album */}
                <div className="album py-5 bg-body-tertiary">
                  <div className="container">
                    <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

                      {/* Card 1 */}
                      <div className="col">
                        <div className="card shadow-sm">
                          <img src="https://picsum.photos/400/250?random=1" className="bd-placeholder-img card-img-top" alt="Book 1" />
                          <div className="card-body">
                            <p className="card-text">
                              Buku motivasi terbaik tahun ini. Cocok untuk kamu yang ingin berkembang.
                            </p>
                            <div className="d-flex justify-content-between align-items-center">
                              <div className="btn-group">
                                <button type="button" className="btn btn-sm btn-outline-primary">View</button>
                                <button type="button" className="btn btn-sm btn-outline-success">Buy</button>
                              </div>
                              <small className="text-body-secondary">Rp 120.000</small>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Card 2 */}
                      <div className="col">
                        <div className="card shadow-sm">
                          <img src="https://picsum.photos/400/250?random=2" className="bd-placeholder-img card-img-top" alt="Book 2" />
                          <div className="card-body">
                            <p className="card-text">
                              Panduan sukses membangun kebiasaan baik dengan langkah kecil setiap hari.
                            </p>
                            <div className="d-flex justify-content-between align-items-center">
                              <div className="btn-group">
                                <button type="button" className="btn btn-sm btn-outline-primary">View</button>
                                <button type="button" className="btn btn-sm btn-outline-success">Buy</button>
                              </div>
                              <small className="text-body-secondary">Rp 95.000</small>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Card 3 */}
                      <div className="col">
                        <div className="card shadow-sm">
                          <img src="https://picsum.photos/400/250?random=3" className="bd-placeholder-img card-img-top" alt="Book 3" />
                          <div className="card-body">
                            <p className="card-text">
                              Buku tentang strategi produktivitas untuk membantu fokus pada tujuan utama.
                            </p>
                            <div className="d-flex justify-content-between align-items-center">
                              <div className="btn-group">
                                <button type="button" className="btn btn-sm btn-outline-primary">View</button>
                                <button type="button" className="btn btn-sm btn-outline-success">Buy</button>
                              </div>
                              <small className="text-body-secondary">Rp 150.000</small>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
        </>
    )
}