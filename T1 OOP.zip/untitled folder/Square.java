public class Square {
    int sisi;

    public void setsisi(int input_sisi){
        sisi = input_sisi;
    }

    public int getsisi(){
        return sisi;
    }

    public int getluas(){
        return sisi * sisi;
    }

    public int getkel(){
        return 4 * sisi  ;
    }
}
