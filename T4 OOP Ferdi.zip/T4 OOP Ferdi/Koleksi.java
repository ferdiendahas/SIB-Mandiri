public class Koleksi {
    String Judul;
    String Penerbit;
    int Tahun;
    public Koleksi(String judul, String penerbit, int tahun){
        this.Judul = judul;
        this.Penerbit = penerbit;
        this.Tahun = tahun;
    }

    public Koleksi(){

    }

    public String toStirng(){
        return "Judul : " + Judul + ", Penerbit : " + Penerbit + ", Tahun : " + Tahun;
    }
    
}   