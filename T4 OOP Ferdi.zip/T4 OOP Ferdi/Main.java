public class Main {
    public static void main(String[] args) {
        Buku buku1 = new Buku("Satu 1% Setiap Hari","Andi Kurniawan", "Gramedia", 2024 );
        Buku buku2 = new Buku("An Extraordinary","Hwang", "Gramedia", 2018 );
        Majalah majalah1 = new Majalah("Pood Dad Rich Dad", "Edisi 2", "Wolf of Wall Street", 1997);
        Skripsi skripsi1 = new Skripsi("23081010165","Ferdi Endahas", "Perkembangan Blockchain Terhadap Tingkah laku Manusia di Tahun 2030", "UPNV Jatim", 2026);

        System.out.println(buku1);
        System.out.println(buku2);
        System.out.println(majalah1);
        System.out.println(skripsi1);

    }
    
}