public class Majalah extends Koleksi {
    String Edisi;
    public Majalah(String judul,String edisi, String penerbit, int tahun){
        super(judul, penerbit, tahun);
        this.Edisi = edisi;
    }

    public Majalah(){

    }

    public String toString(){
        return toStirng() + ", Edisi : " + Edisi;
    }
}
