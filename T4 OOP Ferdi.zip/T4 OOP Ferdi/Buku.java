public class Buku extends Koleksi {
    String Penulis;

    public Buku(String judul,String penulis, String penerbit, int tahun){
        super(judul, penerbit, tahun);
        this.Penulis = penulis;
    }

    public Buku(){

    }

    public String toString(){
        return toStirng() + ", Penulis : " + Penulis;
    }
}
