public class Skripsi extends Buku {
    String NPM;
    public Skripsi(String npm, String penulis, String judul, String penerbit, int tahun){
        super(penulis, judul, penerbit, tahun);
        this.NPM = npm;
    }

    public Skripsi(){

    }

    public String toString(){
        return "NPM : " + NPM + ", " + toStirng();
    }
}
